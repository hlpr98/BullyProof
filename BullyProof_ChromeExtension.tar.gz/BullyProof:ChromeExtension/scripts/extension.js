document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('status').textContent = "Enter Twitter username to activate BullyProof:";
    var button = document.getElementById('changelinks');
    document.getElementById('status2').textContent = "Enter guardian's email id:";
    var button = document.getElementById('changelinks');
    button.addEventListener('click', function () {
        $('#status').html('Clicked enter button');
        var text = $('#linkstext').val();
        var text2 = $('#linkstext2').val();        
        if (!text) {
            $('#status').html('Invalid text provided');
            return;
        }

        
        
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            

            chrome.tabs.sendMessage(tabs[0].id, {data: text}, function(response) {
            $('#status').html('Username entered successfully');
            console.log('Success');
            });
        });

        
        chrome.tabs.create({url: 'https://twitter.com/' + text},callback);
        function callback(data)
        {
            console.log(data.url);
        }
    });
});

